new Vue({
    el: '#vue',
        data: {
            itemRec: [
                {
                    id: 1,
                    item_name: 1,
                    quantity: 1,
                    uom: 1,
                    c_text: 'item1',
                    rate: 1,
                },
                {
                    id: 2,
                    item_name: 2,
                    quantity: 1,
                    uom: 2,
                    c_text: 'item2',
                    rate: 1,
                }
            ],
            selectMonth:[
                {
                    id:1,
                    name:'January',
                },{
                    id:2,
                    name:'February',
                },{
                    id:3,
                    name:'March',
                },{
                    id:4,
                    name:'April',
                },
            ],
            item: {},
            editMode:false,
            editObject: null,
            total:0,
            alltransaction:[],
        },
        methods: {
            opendept()
            {
                alert('aa');
            },
            fetchLastransactions()
            {
                $.ajax({
                    url:  'index.php?r=salarytransaction/fetchtransaction',
                    type: 'GET',
                    data: { id: 1},
                    dataType: 'json',
                }).done(response => {
                   //rec = $.parseJSON(response);
                    this.alltransaction = JSON.parse(JSON.stringify(response))
                  alertify.success('Saved!');
                })
            },
            generatesalary()
            {
               $.ajax({
                    url:  'index.php?r=salarytransaction/generatesalary',
                    type: 'GET',
                    data: { id: 1},
                    dataType: 'json',
                }).done(response => {
                   //rec = $.parseJSON(response);
                    this.alltransaction = JSON.parse(JSON.stringify(response))
                  alertify.logPosition("bottom right")
                  alertify.error('Invalid Selection')
                })
            },
        },
        created() {
        }
    })
